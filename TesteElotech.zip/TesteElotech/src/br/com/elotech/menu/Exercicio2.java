package br.com.elotech.menu;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercicio2 {

	
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Integer numeroInformado;
		Integer auxiliar;
		boolean insereEspaco=true;
		
		  try {
				System.out.printf("Informe o n�mero: ");
				numeroInformado = ler.nextInt();
			    auxiliar= numeroInformado-1;
			    ler.close();
			    if(numeroInformado<2) {
			    	System.err.printf("\nErro: Deve possuir, no m�nimo, 2 degraus !!!\n");
			    	return;
			    }
				

		    }
		    catch (InputMismatchException e) {
		      System.err.printf("\nErro: dados informados inv�lidos !!!\n");
		      auxiliar=0;
		      numeroInformado=0;
		    }
		
        for(int linha = 0; linha < numeroInformado; linha++) {
        	insereEspaco=true;
            for(int coluna = auxiliar; coluna >= 0; coluna--) {
                if(linha>=coluna) {
                	System.out.print("#");
                	insereEspaco=false;       	
                } if(insereEspaco) {
                	   System.out.print(" ");
                }
             
            }
            System.out.println();
        }
	   
    }

}
