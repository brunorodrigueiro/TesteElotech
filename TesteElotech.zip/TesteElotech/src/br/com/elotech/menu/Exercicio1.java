package br.com.elotech.menu;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Integer numeroInformado;
		ArrayList<Integer> listaNumeros = new ArrayList<>();
		HashSet<Integer> numerosRepetidos = new HashSet<>();
		Integer contador;
		
		for(int i=1;i<11;i++) {
			 System.out.printf("Informe o "+i+"� n�mero: ");
			 numeroInformado = ler.nextInt();
			 listaNumeros.add(numeroInformado);
		}
		
		ler.close();
		
		for (Integer numero : listaNumeros) {
			contador=0;
			for(int i=0;i<listaNumeros.size();i++) {
				if(listaNumeros.get(i).compareTo(numero)==0){
					contador++;
				}
				if(contador>1) {
					numerosRepetidos.add(numero);
				}
			}			
		}
		if(numerosRepetidos.isEmpty()) {
			System.out.println("\nNenhum n�mero repetido");
		
		} else {
			System.out.println("\nOs N�meros repetidos s�o: ");
			for (Integer numeroRepetido : numerosRepetidos) {
				System.out.println(numeroRepetido);
			}
		}
	
	
	}

}
