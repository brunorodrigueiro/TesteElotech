package br.com.elotech.menu;


import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		Integer valor1;
	    Integer valor2;
	    Integer valor3;
	    Scanner ler = new Scanner(System.in);
	    Integer resto=0;
	    Integer order1=0;
	    Integer order2=0;
	    Integer order3=0;
	    
	    try {
	    	System.out.printf("Informe o 1� n�mero para o conjunto: ");
			valor1 = ler.nextInt();
			System.out.printf("Informe o 2� n�mero para o conjunto: ");
			valor2 = ler.nextInt();
			System.out.printf("Informe o 3� n�mero para o conjunto: ");
			valor3 = ler.nextInt();
		    ler.close();
		
	    }
	    catch (InputMismatchException e) {
	      System.err.printf("\nErro: dados informados inv�lidos !!!\n");
	      valor1=0;
	      valor2=0;
	      valor3=0;
	    }

	if(valor1>valor2) {
		if(valor1>valor3) {
			order3=valor1;
		} else {
			order2=valor1;
		}
	}else {
		if(valor1>valor3) {
			order2=valor1;
		} else {
			order1=valor1;
		}
	}if(valor2>valor3) {
		if(valor2>valor1) {
			order3=valor2;
		}else {
			order2=valor2;
		}
	}else {
		if(valor2>valor1) {
			order2=valor2;
		}else {
			order1=valor2;
		}
	}if(valor3>valor1) {
		if(valor3>valor2) {
			order3=valor3;
		}else {
			order2=valor3;
		}
	}else {
		if(valor3>valor2) {
			order2=valor3;
		}else {
			order1=valor3;
		}
	}
	
	System.out.print("\nO MDC do conjunto["+order1+", "+order2+", "+order3+"] �: ");
	while(order3!=0) {
    	resto=order2%order3;
    	order1=order2;
    	order2=order3;
    	order3=resto;
    }

	System.out.print(order2);	
}
}
