package br.com.elotech.menu;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		ArrayList<Integer> listaDeNotas= new ArrayList<>();
		ArrayList<Integer> listaTroco;
		Scanner ler = new Scanner(System.in);
		Integer valorConta;
		Integer valorPago;
		Integer valorTroco;
		Integer quantidade=0;
		String resposta;
		boolean inicializador= true;
		
		listaDeNotas.add(100);
		listaDeNotas.add(50);
		listaDeNotas.add(20);
		listaDeNotas.add(10);
		listaDeNotas.add(5);
		listaDeNotas.add(2);
		listaDeNotas.add(1);
		
		while(inicializador) {
		  quantidade=0;
		  listaTroco=new ArrayList<>();
		  try {
				System.out.printf("Informe o valor da conta: R$");
				valorConta = ler.nextInt();
				
				System.out.printf("Informe o valor pago: R$");
				valorPago = ler.nextInt();
				
				valorTroco=valorPago-valorConta;
				if(valorTroco<0) {
					System.err.printf("\nErro: valor insuficiente !!!\n");
					return;
				}
			
		    }
		    catch (InputMismatchException e) {
		      System.err.printf("\nErro: dados informados inv�lidos !!!\n");
		      valorPago=0;
		      valorConta=0;
		      valorTroco=0;
		    }

		 
		 
		 System.out.println("\nO valor do Troco �: R$"+valorTroco);
		 while(valorTroco>0){
			 if(valorTroco>=100) {
				 listaTroco.add(100);
				 valorTroco=valorTroco-100;
			 } else  if(valorTroco>=50) {
				 listaTroco.add(50);
				 valorTroco=valorTroco-50;
			 } else  if(valorTroco>=20) {
				 listaTroco.add(20);
				 valorTroco=valorTroco-20;
			 } else  if(valorTroco>=10) {
				 listaTroco.add(10);
				 valorTroco=valorTroco-10;
			 } else  if(valorTroco>=5) {
				 listaTroco.add(5);
				 valorTroco=valorTroco-5;
			 } else  if(valorTroco>=2) {
				 listaTroco.add(2);
				 valorTroco=valorTroco-2;
			 } else  if(valorTroco>=1) {
				 listaTroco.add(1);
				 valorTroco=valorTroco-1;
			 } 
		 }
		 System.out.println("\nNotas para Troco: ");
		 System.out.println("------------------");
		 for(int i=0;i<listaDeNotas.size();i++) {
			 quantidade=0;
			 for(int x=0;x<listaTroco.size();x++) {
				 if(listaDeNotas.get(i)==listaTroco.get(x)) {
					 quantidade++;
				 } 
			 }
			 if(quantidade!=0) {
				 if(quantidade>1) {
					 System.out.println(quantidade+" notas de R$"+listaDeNotas.get(i));	 
				 } else {
					 System.out.println(quantidade+" nota de R$"+listaDeNotas.get(i));
				 }
				 	 
			 }
			 
		 }
		 System.out.printf("\nDeseja Repetir a execu��o? S/N: ");
			resposta = ler.next();
			resposta = resposta.toUpperCase();
			if(!resposta.equals("S")) {
				inicializador=false;
				ler.close();
				System.out.println("\nFinalizado.");
			}
			System.out.printf("\n");	
		}
		
	
	}

}
