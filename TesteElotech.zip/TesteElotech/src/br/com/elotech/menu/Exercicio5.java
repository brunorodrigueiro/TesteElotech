package br.com.elotech.menu;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Exercicio5 {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Integer numero,quebras=0;
		int soma = 0;	
		int[] listNumeros;
		boolean repetido=false;
		Set<Integer> listaCalculados = new HashSet<Integer>();
		
		System.out.printf("Informe o n�mero: ");
		numero = ler.nextInt();
		listNumeros = digitosNumero(numero);
		ler.close();
		
		for (int i=0;i<listNumeros.length;i++) {
			soma += Math.pow(listNumeros[i],2);
		}
		while ((soma!=1) && !(repetido)){		
			  soma = 0;		
			  for (int i=0;i<listNumeros.length;i++) {
				  soma += Math.pow(listNumeros[i],2);
			  } 				
			  listNumeros = digitosNumero(soma);
			  if (listaCalculados.contains(soma)) {
				  repetido = true;
			  }	else {
				  listaCalculados.add(soma);
				  quebras++;
			  }	
	    }
		if (repetido) {
			System.out.println("\nO n�mero "+numero+" n�o � um n�mero feliz, pois ap�s quebr�-lo diversas vezes o resultado come�a a se repetir.");
			System.out.println("Ou seja, o resultado nunca chegar� a 1.");
		}else {
			System.out.println("\nO n�mero "+numero+" � um n�mero feliz, e necessita de "+quebras+" quebras.");
		}
			
	}
	
	public static int[] digitosNumero(int numero){
		  String numerosConvertidos = Integer.toString(numero);
		  int[] listaNumerosDigitos = new int[numerosConvertidos.length()];
		  int digito = 0;
		  while (numero>0){
		    listaNumerosDigitos[digito] = numero%10;
		    numero = numero/10;  
		    digito++;
		  }
		 
		  return listaNumerosDigitos;
		 
	}
	
}